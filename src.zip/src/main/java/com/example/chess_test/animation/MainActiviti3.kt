//package com.example.chess_test.animation
//
//import android.app.Activity
//import android.content.Context
//import android.content.ContextWrapper
//import android.os.Bundle
//import androidx.activity.ComponentActivity
//import androidx.activity.compose.setContent
//import androidx.compose.animation.*
//import androidx.compose.animation.core.animateFloatAsState
//import androidx.compose.animation.core.tween
//import androidx.compose.foundation.interaction.MutableInteractionSource
//import androidx.compose.foundation.interaction.collectIsPressedAsState
//import androidx.compose.foundation.layout.*
//import androidx.compose.material3.Button
//import androidx.compose.material3.MaterialTheme
//import androidx.compose.material3.Surface
//import androidx.compose.material3.Text
//import androidx.compose.runtime.*
//import androidx.compose.ui.Alignment
//import androidx.compose.ui.Modifier
//import androidx.compose.ui.draw.scale
//import androidx.compose.ui.platform.LocalContext
//import androidx.compose.ui.tooling.preview.Preview
//import androidx.compose.ui.unit.dp
//import kotlinx.coroutines.delay
//import kotlinx.coroutines.launch
//
//class MainActivity3 : ComponentActivity() {
//    override fun onCreate(savedInstanceState: Bundle?) {
//        super.onCreate(savedInstanceState)
//        setContent {
//
//                // A surface container using the 'background' color from the theme
//                Surface(
//                    modifier = Modifier.fillMaxSize(),
//                    color = MaterialTheme.colorScheme.background
//                ) {
//                    AppScreen3()
//                }
//
//        }
//    }
//}
//
///**
// * An extension function to find the Activity from a Context.
// * This is necessary because Jetpack Compose Composable functions receive a Context,
// * but to finish the app, we need to access the Activity.
// */
//fun Context.findActivity3(): Activity? = when (this) {
//    is Activity -> this
//    is ContextWrapper -> baseContext.findActivity3()
//    else -> null
//}
//
//@Composable
//fun AppScreen3() {
//    // Get the current context in the Composable scope
//    val context = LocalContext.current
//
//    // States to control the animations for each element
//    var showText by remember { mutableStateOf(false) }
//    var showButton by remember { mutableStateOf(false) }
//
//    // A coroutine scope is needed for the animation delay
//    val coroutineScope = rememberCoroutineScope()
//
//    // LaunchedEffect runs a suspend block when the key changes.
//    // An empty list `remembered` ensures it runs only once when the composable is first displayed.
//    LaunchedEffect(key1 = true) {
//        // Stagger the animations to make them appear sequentially
//        delay(100) // Delay before text animation starts
//        showText = true // Trigger the text animation
//        delay(200) // Delay before button animation starts
//        showButton = true // Trigger the button animation
//    }
//
//    Column(
//        modifier = Modifier
//            .fillMaxSize()
//            .padding(16.dp),
////            .animateContentSize(), // This modifier fixes the "jump" by animating size changes
//        horizontalAlignment = Alignment.CenterHorizontally,
//        verticalArrangement = Arrangement.Center
//    ) {
//        // AnimatedVisibility for the text, sliding in from the top
//        AnimatedVisibility(
//            visible = showText,
////            enter = fadeIn(animationSpec = tween(durationMillis = 700)) +
////                    slideInVertically(
////                        initialOffsetY = { 0 }, animationSpec
////                        = tween(durationMillis = 700)
////                    ),
//            exit = fadeOut(animationSpec = tween(durationMillis = 700)) +
//                    slideOutVertically(
//                        animationSpec
//                        = tween(durationMillis = 500)
//                    ) { fullHeight -> -fullHeight }
//        ) {
//            Text(
//                text = "Welcome to the app!",
//                style = MaterialTheme.typography.headlineMedium
//            )
//        }
//
//        Spacer(modifier = Modifier.height(32.dp))
//
//        // AnimatedVisibility for the button, sliding in from the bottom
//        AnimatedVisibility(
//            visible = showButton,
////            enter = fadeIn(animationSpec = tween(durationMillis = 500))
////                    + slideInVertically(initialOffsetY = { it }, animationSpec = tween(durationMillis = 500)),
//            exit = fadeOut(animationSpec = tween(durationMillis = 500)) +
//                    slideOutVertically(animationSpec = tween(durationMillis = 500)) { fullHeight -> fullHeight }
//        ) {
//            ExitAppButton3(onExitClick = {
//                // Trigger the exit animations by changing the states
//                showText = false
//                showButton = false
//
//                // Start a coroutine to wait for the animation to finish
//                // before exiting the app
//                coroutineScope.launch {
//                    delay(500) // Wait for the 500ms exit animation to complete
//                    context.findActivity3()?.finishAffinity()
//                }
//            })
//        }
//    }
//}
//
//@Composable
//fun ExitAppButton3(onExitClick: () -> Unit) {
//    // We use an InteractionSource to detect press gestures
//    val interactionSource = remember { MutableInteractionSource() }
//    val isPressed by interactionSource.collectIsPressedAsState()
//
//    // Animate the scale of the button based on its pressed state
//    val scale by animateFloatAsState(
//        targetValue = if (isPressed) 0.95f else 1f, // Corrected scale value
//        label = "buttonScaleAnimation"
//    )
//
//    Button(
//        onClick = onExitClick,
//        modifier = Modifier
//            .width(200.dp)
//            .scale(scale), // Apply the animated scale modifier
//        interactionSource = interactionSource // Pass the interaction source to the button
//    ) {
//        Text(text = "Exit Application")
//    }
//}
//
//@Preview(showBackground = true)
//@Composable
//fun DefaultPreview3() {
//        AppScreen3()
//
//}
