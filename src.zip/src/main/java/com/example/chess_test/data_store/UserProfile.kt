package com.example.chess_test.data_store

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainProfileScreen : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {

                Surface(modifier = Modifier.fillMaxSize()) {
                    ProfileScreen()
                }

        }
    }
}

@Composable
fun ProfileScreen() {
    val context = LocalContext.current
    val savedUsername = remember { mutableStateOf("") }
    val savedPassword = remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    // Load saved credentials from DataStore
    LaunchedEffect(Unit) {
        scope.launch {
            UserPreferences.getCredentials(context).collectLatest { (userName, password) ->
                savedUsername.value = userName
                savedPassword.value = password
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(text = "👤 User Profile", style = MaterialTheme.typography.headlineSmall)
        HorizontalDivider()
        Text(text = "Username: ${savedUsername.value}", style = MaterialTheme.typography.bodyLarge)
        Text(text = "Password: ${savedPassword.value}", style = MaterialTheme.typography.bodyLarge)
    }
}
