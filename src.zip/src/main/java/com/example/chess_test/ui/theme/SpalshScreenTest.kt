package com.example.chess_test.ui.theme

import android.os.Handler
import android.os.Looper
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.chessgame.R
import com.example.chessgame.color.Moccasin

@Composable
fun SplashScreenTest(navController: NavController,themeViewModel: ThemeViewModel) {
    val backgroundColor = themeViewModel.backgroundColor
//    delay=2 second to first screen
    LaunchedEffect(Unit) {
        Handler(Looper.getMainLooper()).postDelayed({
            navController.popBackStack()
            navController.navigate("Login screen")
        }, 2000)
    }
    Box(
        modifier = Modifier
            .fillMaxSize(),
        contentAlignment = Alignment.Center
    ) {
        Image(
            modifier = Modifier
                .fillMaxSize()
                .padding(6.dp)
                .background(backgroundColor)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )
    }

}
