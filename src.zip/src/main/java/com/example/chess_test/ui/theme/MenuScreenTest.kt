package com.example.chess_test.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chessgame.R
import com.example.chessgame.color.SaddleBrown
import com.example.chessgame.color.Sienna
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

fun Context.findActivity3M(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity3M()
    else -> null
}

@Composable
fun MenuScreenTest(navController: NavController, themeViewModel: ThemeViewModel) {

    val coroutineScope = rememberCoroutineScope()
    val shouldShowDialog = remember { mutableStateOf(false) }
    if (shouldShowDialog.value) {
        AlertDialogMenuScreen(
            navController = navController,
            shouldShowDialog = shouldShowDialog
        )
    }

    val backgroundColor = themeViewModel.backgroundColor
    val font = themeViewModel.font
    val fontSize = themeViewModel.fontSize
    Box(
        modifier = Modifier
            .fillMaxSize(),
    ) {
        Image(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.5f)
                .padding(6.dp)
                .background(backgroundColor)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
//            verticalArrangement = Arrangement.Center
        ) {

            Text(
                text = "Menu Screen",
                modifier = Modifier
                    .padding(top = 36.dp),
                fontFamily = font,
                fontSize = fontSize,
                color = Sienna,
            )
            Spacer(modifier = Modifier.height(16.dp))
            Button(
                onClick = {
                    navController.navigate("New Game Screen")
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                shape = RoundedCornerShape(32.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "New Game",
                    modifier = Modifier
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    fontFamily = font,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    color = SaddleBrown
                )
            }
            Button(
                onClick = {
                    navController.navigate("Game Screen")
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                shape = RoundedCornerShape(32.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Settings",
                    modifier = Modifier
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    fontFamily = font,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    color = SaddleBrown
                )
            }
            Button(
                onClick = {
                    navController.navigate("About screen")
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                shape = RoundedCornerShape(32.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "About",
                    modifier = Modifier
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    fontFamily = font,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    color = SaddleBrown
                )
            }

            Button(
                onClick = {
                    coroutineScope.launch {
                        delay(500)
                        shouldShowDialog.value = true
                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                shape = RoundedCornerShape(32.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Back to Login Screen",
                    modifier = Modifier
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    fontFamily = font,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    color = SaddleBrown
                )
            }
        }

    }
    BackHandler(enabled = true) {
        shouldShowDialog.value = true
    }
}

@Composable
fun AlertDialogMenuScreen(
    navController: NavController,
    shouldShowDialog: MutableState<Boolean>
) {
    val context = LocalContext.current
    if (shouldShowDialog.value) {
        AlertDialog(
            onDismissRequest = {
                shouldShowDialog.value = false
            },
            title = { Text(text = "Alert") },
            text = { Text(text = "Going back to main screen?") },
            confirmButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
//                        context.findActivity3()?.finishAffinity()
                        navController.popBackStack()
                        navController.navigate("Login screen")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                )
                {
                    Text(
                        text = "Confirm",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                ) {
                    Text(
                        text = "Dismiss",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            }

        )
    }
}


@Preview(showBackground = true)
@Composable
fun MenuScreenPreview() {
    MenuScreenTest(
        navController = rememberNavController(),
        themeViewModel = viewModel()
    )
}

