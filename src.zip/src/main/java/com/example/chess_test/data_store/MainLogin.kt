package com.example.chess_test.data_store


import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextField
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

class MainLoginScreen : ComponentActivity(){
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent{
            LoginScreen()
        }
    }
}

@Composable
fun LoginScreen() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    val inputUsername = remember { mutableStateOf("") }
    val inputPassword = remember { mutableStateOf("") }

    val storedUsername = remember { mutableStateOf("") }
    val storedPassword = remember { mutableStateOf("") }

    // Load stored credentials once
    LaunchedEffect(Unit) {
        scope.launch {
            UserPreferences.getCredentials(context).collectLatest { (username, password) ->
                storedUsername.value = username
                storedPassword.value = password
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(24.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("🔐 Login", style = MaterialTheme.typography.headlineSmall)

        TextField(
            value = inputUsername.value,
            onValueChange = { inputUsername.value = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        TextField(
            value = inputPassword.value,
            onValueChange = { inputPassword.value = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                if (inputUsername.value == storedUsername.value &&
                    inputPassword.value == storedPassword.value
                ) {
                    Toast.makeText(context, "✅ Login successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(context, "❌ Failed to connect. Invalid credentials.", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Login")
        }
    }
}
