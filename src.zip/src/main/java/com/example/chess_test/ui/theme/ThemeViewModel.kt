package com.example.chess_test.ui.theme

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import com.example.chessgame.color.Moccasin


class ThemeViewModel : ViewModel() {
    var backgroundColor by mutableStateOf(Moccasin)
    var font by mutableStateOf(FontFamily.Default)
    var fontSize by mutableStateOf(16.sp)
}