package com.example.chess_test

import android.media.MediaPlayer
import android.util.Log
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chess_test.ui.theme.ThemeViewModel
import com.example.chessgame.R
import com.example.chessgame.color.Beige
import com.example.chessgame.color.Black
import com.example.chessgame.color.Blue
import com.example.chessgame.color.BurlyWood
import com.example.chessgame.color.Gainsboro
import com.example.chessgame.color.Indigo
import com.example.chessgame.color.LightPink
import com.example.chessgame.color.Moccasin
import com.example.chessgame.color.NavajoWhite
import com.example.chessgame.color.Red
import com.example.chessgame.color.SaddleBrown
import com.example.chessgame.color.Sienna
import com.example.chessgame.color.White
import com.example.chessgame.color.Yellow
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext


@Composable
fun GameScreenTest(navController: NavController, themeViewModel: ThemeViewModel) {
    var flag by remember { mutableStateOf(false) }

    val backgroundColor = themeViewModel.backgroundColor
    val font = themeViewModel.font
    val fontSize = themeViewModel.fontSize

    val context = LocalContext.current
    val mediaPlayer = remember { MediaPlayer.create(context, R.raw.music) }
    val coroutineScope = rememberCoroutineScope()

    var isPlaying by remember { mutableStateOf(false) }
    var isPaused by remember { mutableStateOf(false) }


    DisposableEffect(Unit) {
        onDispose {
            mediaPlayer.release()
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor),
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        //   verticalArrangement = Arrangement.Center
    ) {
        Text(
            text = "Game Screen",
            modifier = Modifier
                .padding(top = 36.dp),
            fontFamily = font,
            fontSize = (24.sp),
            fontWeight = FontWeight.Bold,
            color = Sienna,
        )
        Spacer(modifier = Modifier.height(16.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Button(
                onClick = {
                    flag = !flag
                    themeViewModel.backgroundColor = Moccasin
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(
                        0xFFDEB887
                    ).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(160.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "B.G Color",
                    modifier = Modifier,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = font,
                    color = SaddleBrown
                )
            }
            Button(
                onClick = {
                    flag = !flag
                    themeViewModel.backgroundColor = NavajoWhite
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFDEAD).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "NavajoWhite",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black

                )
            }
            Button(
                onClick = {
//                    navController.navigate("Red" ----> nemidunam chera vali vaghti in cod hasr crash mikhore va mipare birun
                    flag = !flag
                    themeViewModel.backgroundColor = LightPink
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFFFB6C1).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "LightPink",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black

                )
            }
            Button(
                onClick = {
//                    navController.navigate("Yellow")
                    flag = !flag
                    themeViewModel.backgroundColor = Beige
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFF5F5DC).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Beige",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black

                )
            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Button(
                onClick = {
                    flag = !flag
                    themeViewModel.font = FontFamily.Default
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(
                        0xFFDEB887
                    ).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(120.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Font",
                    modifier = Modifier,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = font,
                    color = SaddleBrown
                )
            }
            Button(
                onClick = {
//                    Log.d("MyChess", "login")
                    flag = !flag
                    themeViewModel.font = FontFamily.Cursive
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(80.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "Cursive",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Cursive,
                    color = Black
                )

            }
            Button(
                onClick = {
//                    Log.d("MyChess", "login")
                    flag = !flag
                    themeViewModel.font = FontFamily.SansSerif
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(80.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "SansSerif",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Monospace,
                    color = Black
                )

            }
            Button(
                onClick = {
//                    Log.d("MyChess", "login")
                    flag = !flag
                    themeViewModel.font = FontFamily.Serif
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "Serif",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )

            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            Button(
                onClick = {
                    flag = !flag
                    themeViewModel.fontSize = 12.sp
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(
                        0xFFDEB887
                    ).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(160.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Font Size",
                    modifier = Modifier,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = font,
                    color = SaddleBrown
                )
            }
            Button(
                onClick = {
//                    Log.d("MyChess", "login")
                    flag = !flag
                    themeViewModel.fontSize = 12.sp
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "12",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )

            }
            Button(
                onClick = {
//                    Log.d("MyChess", "login")
                    flag = !flag
                    themeViewModel.fontSize = 14.sp
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "14",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )

            }
            Button(
                onClick = {

                    flag = !flag
                    themeViewModel.fontSize = 16.sp
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "16",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )

            }
        }
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(8.dp),
            horizontalArrangement = Arrangement.spacedBy(2.dp)
        ) {
            //music
            Button(
                onClick = {
                    flag = !flag
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(
                        0xFFDEB887
                    ).copy(alpha = 0.4f)
                ),
                modifier = Modifier
                    .width(160.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)
            ) {
                Text(
                    text = "Music On/Off",
                    modifier = Modifier,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    fontFamily = font,
                    color = SaddleBrown
                )
            }
            // OnMusicButton
            Button(
                onClick = {
                    coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                            if (!mediaPlayer.isPlaying) {
                                mediaPlayer.start()
                            }
                        }
                        isPlaying = true
                        isPaused = false

                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f),
                    disabledContainerColor = Color.Green,          // Background when button is disabled
                    disabledContentColor = Color.LightGray        // Text/icon color when disabled
                ),
                enabled = !isPlaying,
//                enabled = true, // Set to false to disable the button
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "On",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )
            }
            // OffMusicButton
            Button(
                onClick = {
                    coroutineScope.launch {
                        withContext(Dispatchers.IO) {
                            if (mediaPlayer.isPlaying || mediaPlayer.currentPosition > 0) {
                                mediaPlayer.stop()
                                mediaPlayer.reset()
                                mediaPlayer.setDataSource(context.resources.openRawResourceFd(R.raw.music))
                                mediaPlayer.prepare()
                            }
                        }
                        isPlaying = false
                        isPaused = false

                    }
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color(0xFFDEB887).copy(alpha = 0.4f),
                    disabledContainerColor = Red,          // Background when button is disabled
                    disabledContentColor = Color.LightGray        // Text/icon color when disabled
                ),
                enabled = isPlaying || isPaused,
//                enabled = false, // Set to false to disable the button
                modifier = Modifier
                    .width(60.dp)
                    .height(40.dp),
                shape = RoundedCornerShape(32.dp),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
                elevation = ButtonDefaults.buttonElevation(0.dp)

            ) {
                Text(
                    text = "Off",
                    modifier = Modifier,
                    fontSize = (10.sp),
                    fontWeight = FontWeight.Bold,
                    fontFamily = FontFamily.Serif,
                    color = Black
                )
            }


        }
        Button(
            onClick = {
                navController.popBackStack()
//                navController.navigate("Menu Screen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(
                    0xFFDEB887
                ).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .padding(16.dp)
                .width(160.dp)
                .height(40.dp),
            shape = RoundedCornerShape(32.dp),
            contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Back",
                modifier = Modifier,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Image(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.5f)
                .padding(6.dp)
                .background(backgroundColor)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )

    }

}



@Preview(showBackground = true)
@Composable
fun GameScreenPreview() {
    GameScreenTest(
        navController = rememberNavController(),
        themeViewModel = viewModel() // This assumes ThemeViewModel is @HiltViewModel or similarly provided
    )
}