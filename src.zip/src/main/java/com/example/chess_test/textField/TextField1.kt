package com.example.chess_test.textField


import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.font.FontWeight

class MainTextFieldActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            TextFieldWithResetButton()
        }
    }
}

@Composable
fun TextFieldWithResetButton() {
    var textState by remember { mutableStateOf(TextFieldValue("")) }

    Box(
        modifier = Modifier
            .fillMaxSize() // Fill the entire screen size
            .background(Color.LightGray) // Background color
            .border(2.dp, Color.DarkGray) // Border with color and width
            .padding(16.dp) // Padding inside the box
            .clip(RoundedCornerShape(16.dp)), // Rounded corners
        contentAlignment = Alignment.Center // Center content in the box
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally, // Center items horizontally
            verticalArrangement = Arrangement.spacedBy(16.dp) // Space between items
        ) {
            TextField(
                value = textState, // Current value of the text field
                onValueChange = { textState = it }, // Update the value on change
                modifier = Modifier
                    .fillMaxWidth() // Make the text field stretch to full width
                    .border(1.dp, Color.Gray, RoundedCornerShape(8.dp)) // Border and shape
                    .padding(8.dp), // Padding around the text field
                textStyle = TextStyle(
                    color = Color.Black, // Text color
                    fontSize = 16.sp, // Text size
                    textAlign = TextAlign.Start // Text alignment
                ),
                placeholder = { Text("Enter text here...") }, // Placeholder text
                singleLine = true // Restrict to a single line
            )

            Button(
                onClick = { textState = TextFieldValue("") }, // Clear the text field on click
                modifier = Modifier
                    .width(200.dp) // Button width
                    .height(50.dp) // Button height
                    .clip(RoundedCornerShape(25.dp)) // Rounded shape for oval button
                    .border(2.dp, Color.Black, RoundedCornerShape(25.dp)), // Border for button
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Red, // Button background color
                    contentColor = Color.White // Button text color
                ),
                shape = RoundedCornerShape(25.dp), // Button shape
                elevation = ButtonDefaults.buttonElevation(4.dp) // Button elevation
            ) {
                Text(
                    text = "Reset", // Button text
                    fontSize = 20.sp, // Text size
                    fontWeight = FontWeight.Bold, // Text weight
                    textAlign = TextAlign.Center // Text alignment
                )
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun PreviewTextFieldWithResetButton() {
    TextFieldWithResetButton()
}
