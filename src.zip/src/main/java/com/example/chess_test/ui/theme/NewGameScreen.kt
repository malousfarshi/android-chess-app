package com.example.chess_test.ui.theme


import android.content.Intent
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chessgame.R
import com.example.chessgame.color.Black
import com.example.chessgame.color.BurlyWood
import com.example.chessgame.color.PeachPuff
import com.example.chessgame.color.SaddleBrown
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// Convert indices to chessboard notation
fun indexToChessNotation(row: Int, col: Int): String {
    val columnLetter = ('a' + col) // Column index to letter
    val rowNumber = 8 - row       // Row index to chess numbering
    return "$columnLetter$rowNumber"
}


@Composable
fun NewGameScreen(navController: NavController, themeViewModel: ThemeViewModel) {

    val font = themeViewModel.font
    val fontSize = themeViewModel.fontSize

    var selectedPiece by remember { mutableStateOf<String?>(null) }
    var selectedPosition by remember { mutableStateOf<Pair<Int, Int>?>(null) }
    val moveHistory = remember { mutableStateListOf<String>() }

    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()
    val context = LocalContext.current

//    AlertDialog


    val shouldShowDialogBackGame = remember { mutableStateOf(false) }
    if (shouldShowDialogBackGame.value) {
        AlertDialogBackGame(
            navController = navController,
            shouldShowDialog = shouldShowDialogBackGame
        )
    }

    var currentTurn by remember { mutableStateOf("White") }
    var checkStatus by remember { mutableStateOf<String?>(null) }
    var gameStatus by remember { mutableStateOf<String?>(null) } // New state for Checkmate/Stalemate

    // New state variables for castling and en passant
    var whiteKingMoved by remember { mutableStateOf(false) }
    var blackKingMoved by remember { mutableStateOf(false) }
    var whiteRookLeftMoved by remember { mutableStateOf(false) }
    var whiteRookRightMoved by remember { mutableStateOf(false) }
    var blackRookLeftMoved by remember { mutableStateOf(false) }
    var blackRookRightMoved by remember { mutableStateOf(false) }
    var lastPawnDoubleMove by remember { mutableStateOf<Pair<Int, Int>?>(null) } // Tracks the position of a pawn that just moved two squares

    // New state variables for promotion
    var showPromotionDialog by remember { mutableStateOf(false) }
    var promotionPosition by remember { mutableStateOf<Pair<Int, Int>?>(null) }

    var chessBoard by remember {
        mutableStateOf(
            listOf(
                listOf(
                    "Black Rook Left",
                    "Black Knight Left",
                    "Black Bishop Left",
                    "Black Queen",
                    "Black King",
                    "Black Bishop Right",
                    "Black Knight Right",
                    "Black Rook Right"
                ),
                listOf(
                    "Black Pawn 1",
                    "Black Pawn 2",
                    "Black Pawn 3",
                    "Black Pawn 4",
                    "Black Pawn 5",
                    "Black Pawn 6",
                    "Black Pawn 7",
                    "Black Pawn 8"
                ),
                List(8) { "" },
                List(8) { "" },
                List(8) { "" },
                List(8) { "" },
                listOf(
                    "White Pawn 1",
                    "White Pawn 2",
                    "White Pawn 3",
                    "White Pawn 4",
                    "White Pawn 5",
                    "White Pawn 6",
                    "White Pawn 7",
                    "White Pawn 8"
                ),
                listOf(
                    "White Rook Left",
                    "White Knight Left",
                    "White Bishop Left",
                    "White Queen",
                    "White King",
                    "White Bishop Right",
                    "White Knight Right",
                    "White Rook Right"
                )
            )

        )
    }

    // Function to reset the game state to its initial values
    fun resetGame() {
        chessBoard = listOf(
            listOf(
                "Black Rook Left",
                "Black Knight Left",
                "Black Bishop Left",
                "Black Queen",
                "Black King",
                "Black Bishop Right",
                "Black Knight Right",
                "Black Rook Right"
            ),
            listOf(
                "Black Pawn 1",
                "Black Pawn 2",
                "Black Pawn 3",
                "Black Pawn 4",
                "Black Pawn 5",
                "Black Pawn 6",
                "Black Pawn 7",
                "Black Pawn 8"
            ),
            List(8) { "" },
            List(8) { "" },
            List(8) { "" },
            List(8) { "" },
            listOf(
                "White Pawn 1",
                "White Pawn 2",
                "White Pawn 3",
                "White Pawn 4",
                "White Pawn 5",
                "White Pawn 6",
                "White Pawn 7",
                "White Pawn 8"
            ),
            listOf(
                "White Rook Left",
                "White Knight Left",
                "White Bishop Left",
                "White Queen",
                "White King",
                "White Bishop Right",
                "White Knight Right",
                "White Rook Right"
            )
        )
        selectedPiece = null
        selectedPosition = null
        moveHistory.clear()
        currentTurn = "White"
        checkStatus = null
        gameStatus = null
        whiteKingMoved = false
        blackKingMoved = false
        whiteRookLeftMoved = false
        whiteRookRightMoved = false
        blackRookLeftMoved = false
        blackRookRightMoved = false
        lastPawnDoubleMove = null
        showPromotionDialog = false
        promotionPosition = null
    }

    val shouldShowDialogRestartGame = remember { mutableStateOf(false) }
    if (shouldShowDialogRestartGame.value) {
        AlertDialogRestartGame(
            shouldShowDialog = shouldShowDialogRestartGame,
            resetGame ={
                resetGame()
            }
        )
    }

    fun shareGameResult() {
        val shareIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            val shareText = "Game Over!\n${gameStatus ?: "No game status"}\n\nMove History:\n${
                moveHistory.joinToString("\n")
            }"
            putExtra(Intent.EXTRA_TEXT, shareText)
        }
        context.startActivity(Intent.createChooser(shareIntent, "Share Chess Game Result"))
    }


    // Logic to handle the promotion choice
    val onPromotionPieceSelected: (String) -> Unit = { selectedPromotion ->
        val to = promotionPosition
        val newBoard = chessBoard.toMutableList().map { it.toMutableList() }
        newBoard[to!!.first][to.second] = selectedPromotion
        chessBoard = newBoard.map { it.toList() }

        showPromotionDialog = false
        promotionPosition = null

        moveHistory.add(
            "${selectedPromotion} promoted at ${
                indexToChessNotation(
                    to.first,
                    to.second
                )
            }"
        )

        // Finalize turn after promotion
        currentTurn = if (currentTurn == "White") "Black" else "White"
        checkStatus = null
        gameStatus = null

        // Check for checkmate or stalemate after the promotion move
        val opponentKingPos = findKingPosition(chessBoard, currentTurn)
        if (opponentKingPos != null) {
            if (isKingInCheck(
                    chessBoard,
                    opponentKingPos,
                    currentTurn,
                    whiteKingMoved,
                    blackKingMoved,
                    whiteRookLeftMoved,
                    whiteRookRightMoved,
                    blackRookLeftMoved,
                    blackRookRightMoved,
                    lastPawnDoubleMove
                )
            ) {
                checkStatus = "${currentTurn} King is in Check!"
                if (isCheckmate(
                        chessBoard,
                        currentTurn,
                        whiteKingMoved,
                        blackKingMoved,
                        whiteRookLeftMoved,
                        whiteRookRightMoved,
                        blackRookLeftMoved,
                        blackRookRightMoved,
                        lastPawnDoubleMove
                    )
                ) {
                    gameStatus =
                        "Checkmate! ${if (currentTurn == "White") "Black" else "White"} Wins!"
                }
            } else if (isStalemate(
                    chessBoard,
                    currentTurn,
                    whiteKingMoved,
                    blackKingMoved,
                    whiteRookLeftMoved,
                    whiteRookRightMoved,
                    blackRookLeftMoved,
                    blackRookRightMoved,
                    lastPawnDoubleMove
                )
            ) {
                gameStatus = "Stalemate! It's a Draw."
            }
        }
    }


    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(PeachPuff),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        chessBoard.forEachIndexed { rowIndex, row ->
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center
            ) {
                row.forEachIndexed { colIndex, piece ->
                    Box(
                        modifier = Modifier
                            .size(45.dp)
                            .background(if ((rowIndex + colIndex) % 2 == 0) BurlyWood else SaddleBrown)
                            .border(
                                width = if (selectedPosition == rowIndex to colIndex) 3.dp else 0.dp,
                                color = Black
                            )
                            .clickable {
                                // Don't allow clicks if the game is over or a promotion is in progress
                                if (gameStatus != null || showPromotionDialog) return@clickable

                                if (selectedPiece == piece && selectedPosition == rowIndex to colIndex) {
                                    selectedPiece = null
                                    selectedPosition = null
                                } else if (selectedPiece == null && piece.isNotEmpty()) {
                                    if ((currentTurn == "White" && piece.startsWith("White")) ||
                                        (currentTurn == "Black" && piece.startsWith("Black"))
                                    ) {
                                        selectedPiece = piece
                                        selectedPosition = rowIndex to colIndex
                                    }
                                } else if (selectedPiece != null && selectedPosition != null) {
                                    if (isMoveValid(
                                            selectedPiece!!,
                                            selectedPosition!!,
                                            rowIndex to colIndex,
                                            chessBoard,
                                            whiteKingMoved, blackKingMoved,
                                            whiteRookLeftMoved, whiteRookRightMoved,
                                            blackRookLeftMoved, blackRookRightMoved,
                                            lastPawnDoubleMove
                                        )
                                    ) {
                                        val pieceToMove = selectedPiece!!
                                        val from = selectedPosition!!
                                        val to = rowIndex to colIndex

                                        val newChessBoard =
                                            chessBoard.toMutableList().map { it.toMutableList() }
                                        var capturedPiecePos: Pair<Int, Int>? = null

                                        // Check for castling
                                        val isWhiteKing = pieceToMove == "White King"
                                        val isBlackKing = pieceToMove == "Black King"
                                        val isCastling =
                                            (isWhiteKing || isBlackKing) && Math.abs(from.second - to.second) == 2

                                        // Check for en passant
                                        val isEnPassant =
                                            (pieceToMove.startsWith("White Pawn") || pieceToMove.startsWith(
                                                "Black Pawn"
                                            )) &&
                                                    (to.first == from.first + (if (pieceToMove.startsWith(
                                                            "White"
                                                        )
                                                    ) -1 else 1)) && // moving diagonally
                                                    (Math.abs(to.second - from.second) == 1) && // changing column
                                                    (newChessBoard[to.first][to.second].isEmpty()) && // destination is empty
                                                    (lastPawnDoubleMove != null && lastPawnDoubleMove == (from.first to to.second)) // last move was a double pawn move

                                        // Check for promotion
                                        val isPromotion =
                                            (pieceToMove.startsWith("White Pawn") && to.first == 0) ||
                                                    (pieceToMove.startsWith("Black Pawn") && to.first == 7)

                                        if (isCastling) {
                                            val rookRow = from.first
                                            val rookFromCol = if (to.second > from.second) 7 else 0
                                            val rookToCol = if (to.second > from.second) 5 else 3
                                            val rookName = newChessBoard[rookRow][rookFromCol]

                                            newChessBoard[from.first][from.second] = ""
                                            newChessBoard[to.first][to.second] = pieceToMove
                                            newChessBoard[rookRow][rookFromCol] = ""
                                            newChessBoard[rookRow][rookToCol] = rookName

                                            if (isWhiteKing) whiteKingMoved =
                                                true else blackKingMoved = true
                                            if (from.second == 4 && to.second == 6) {
                                                if (isWhiteKing) whiteRookRightMoved =
                                                    true else blackRookRightMoved = true
                                            } else if (from.second == 4 && to.second == 2) {
                                                if (isWhiteKing) whiteRookLeftMoved =
                                                    true else blackRookLeftMoved = true
                                            }

                                        } else if (isEnPassant) {
                                            capturedPiecePos = lastPawnDoubleMove
                                            newChessBoard[from.first][from.second] = ""
                                            newChessBoard[to.first][to.second] = pieceToMove
                                            newChessBoard[capturedPiecePos!!.first][capturedPiecePos.second] =
                                                ""
                                        } else {
                                            newChessBoard[from.first][from.second] = ""
                                            newChessBoard[to.first][to.second] = pieceToMove

                                            when (pieceToMove) {
                                                "White King" -> whiteKingMoved = true
                                                "Black King" -> blackKingMoved = true
                                                "White Rook Left" -> whiteRookLeftMoved = true
                                                "White Rook Right" -> whiteRookRightMoved = true
                                                "Black Rook Left" -> blackRookLeftMoved = true
                                                "Black Rook Right" -> blackRookRightMoved = true
                                            }
                                        }

                                        lastPawnDoubleMove =
                                            if ((pieceToMove.startsWith("White Pawn") || pieceToMove.startsWith(
                                                    "Black Pawn"
                                                )) &&
                                                (Math.abs(from.first - to.first) == 2)
                                            ) {
                                                to
                                            } else {
                                                null
                                            }

                                        chessBoard = newChessBoard.map { it.toList() }

                                        if (isPromotion) {
                                            showPromotionDialog = true
                                            promotionPosition = to
                                            // Don't switch turns yet, or update history
                                        } else {
                                            // Finalize the move for non-promotion pieces
                                            val fromNotation =
                                                indexToChessNotation(from.first, from.second)
                                            val toNotation =
                                                indexToChessNotation(to.first, to.second)
                                            moveHistory.add("$pieceToMove moved from $fromNotation to $toNotation")
                                            if (isEnPassant) {
                                                moveHistory.add(
                                                    "    -> Capturing pawn en passant at ${
                                                        indexToChessNotation(
                                                            capturedPiecePos!!.first,
                                                            capturedPiecePos.second
                                                        )
                                                    }"
                                                )
                                            }

                                            coroutineScope.launch {
                                                listState.animateScrollToItem(
                                                    moveHistory.lastIndex
                                                )
                                            }

                                            currentTurn =
                                                if (currentTurn == "White") "Black" else "White"

                                            // Check for checkmate or stalemate after the move
                                            val opponentKingPos =
                                                findKingPosition(chessBoard, currentTurn)
                                            if (opponentKingPos != null) {
                                                if (isKingInCheck(
                                                        chessBoard,
                                                        opponentKingPos,
                                                        currentTurn,
                                                        whiteKingMoved,
                                                        blackKingMoved,
                                                        whiteRookLeftMoved,
                                                        whiteRookRightMoved,
                                                        blackRookLeftMoved,
                                                        blackRookRightMoved,
                                                        lastPawnDoubleMove
                                                    )
                                                ) {
                                                    checkStatus = "${currentTurn} King is in Check!"
                                                    if (isCheckmate(
                                                            chessBoard,
                                                            currentTurn,
                                                            whiteKingMoved,
                                                            blackKingMoved,
                                                            whiteRookLeftMoved,
                                                            whiteRookRightMoved,
                                                            blackRookLeftMoved,
                                                            blackRookRightMoved,
                                                            lastPawnDoubleMove
                                                        )
                                                    ) {
                                                        gameStatus =
                                                            "Checkmate! ${if (currentTurn == "White") "Black" else "White"} Wins!"
                                                    }
                                                } else if (isStalemate(
                                                        chessBoard,
                                                        currentTurn,
                                                        whiteKingMoved,
                                                        blackKingMoved,
                                                        whiteRookLeftMoved,
                                                        whiteRookRightMoved,
                                                        blackRookLeftMoved,
                                                        blackRookRightMoved,
                                                        lastPawnDoubleMove
                                                    )
                                                ) {
                                                    gameStatus = "Stalemate! It's a Draw."
                                                }
                                            } else {
                                                checkStatus =
                                                    null // King might be captured in a custom setup
                                            }
                                        }

                                        selectedPiece = null
                                        selectedPosition = null
                                    }
                                }
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        piece.takeIf { it.isNotEmpty() }?.let {
                            getPieceImage(it)?.let { imageRes ->
                                Image(
                                    modifier = Modifier
                                        .size(50.dp)
                                        .padding(6.dp)
                                        .clip(shape = RoundedCornerShape(2.dp)),
                                    painter = painterResource(id = imageRes),
                                    contentDescription = it,
                                    contentScale = ContentScale.Fit
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(16.dp))

        checkStatus?.let {
            Text(text = it, color = Color.Red, modifier = Modifier.padding(8.dp))
        }

        gameStatus?.let {
            Text(text = it, color = Color.Blue, modifier = Modifier.padding(8.dp))
        }

        LazyColumn(
            modifier = Modifier
                .align(Alignment.Start)
                .padding(16.dp)
                .height(150.dp),
            state = listState
        ) {
            item {
                Text(
                    text = "Move History:",
                    modifier = Modifier
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    fontFamily = font,
                    fontSize = fontSize,
                    fontWeight = FontWeight.Bold,
                    color = SaddleBrown
                )
            }
            items(moveHistory) { move ->
                Text(text = move, color = Color.DarkGray)
            }
        }

        // Display the promotion dialog if needed
        if (showPromotionDialog) {
            PromotionDialog(
                onPieceSelected = onPromotionPieceSelected,
                isWhite = currentTurn == "White"
            )
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Show the reset button only when the game is over
//        if (gameStatus != null) {
        //restart alertdialog cod
        Button(
            onClick = {
                coroutineScope.launch {
                    delay(500)
                    shouldShowDialogRestartGame.value = true
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .align(Alignment.Start)
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
        ) {
            Text(
                "Restart Game",
                modifier = Modifier
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { shareGameResult() },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .align(Alignment.Start)
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
        ) {
            Text(
                "Share Result",
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                coroutineScope.launch {
                    delay(500)
                    shouldShowDialogBackGame.value = true
                }

            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .align(Alignment.Start)
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
        ) {
            Text(
                text = "Back",
                modifier = Modifier
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
//        }
    }
}

//function to show alert dialog
@Composable
fun AlertDialogRestartGame(shouldShowDialog: MutableState<Boolean>, resetGame: () -> Unit) {
    if (shouldShowDialog.value) {
        AlertDialog(
            onDismissRequest = {
                shouldShowDialog.value = false
            },
            title = { Text(text = "Restart Game?") },
            text = { Text(text = "Are you sure you want to restart the game?") },
            confirmButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                        resetGame()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                )
                {
                    Text(
                        text = "Confirm",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                ) {
                    Text(
                        text = "Dismiss",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            }

        )
    }
}


@Composable
fun AlertDialogBackGame(navController: NavController, shouldShowDialog: MutableState<Boolean>) {
    val context = LocalContext.current
    if (shouldShowDialog.value) {
        AlertDialog(
            onDismissRequest = {
                shouldShowDialog.value = false
            },
            title = { Text(text = "Back to Menu?") },
            text = { Text(text = "Are you sure you want to back to menu?") },
            confirmButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                        navController.popBackStack()
                        navController.navigate("Menu screen")
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                )
                {
                    Text(
                        text = "Confirm",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                ) {
                    Text(
                        text = "Dismiss",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            }

        )
    }
}


// New composable for the promotion dialog
@Composable
fun PromotionDialog(onPieceSelected: (String) -> Unit, isWhite: Boolean) {
    val color = if (isWhite) "White" else "Black"
    val pieces = listOf("Queen", "Rook", "Bishop", "Knight")

    Column(
        modifier = Modifier
            .background(Color.Gray.copy(alpha = 0.8f))
            .padding(16.dp)
            .border(2.dp, Color.Black)
    ) {
        Text("Promote Pawn to:")
        Spacer(modifier = Modifier.height(8.dp))
        Row {
            pieces.forEach { pieceName ->
                val fullPieceName = "$color $pieceName"
                Box(
                    modifier = Modifier
                        .size(45.dp)
                        .clickable { onPieceSelected(fullPieceName) }
                ) {
                    getPieceImage(fullPieceName)?.let { imageRes ->
                        Image(
                            painter = painterResource(id = imageRes),
                            contentDescription = fullPieceName,
                            contentScale = ContentScale.Fit
                        )
                    }
                }
            }
        }
    }
}

// New function to check for checkmate
fun isCheckmate(
    board: List<List<String>>,
    color: String,
    whiteKingMoved: Boolean,
    blackKingMoved: Boolean,
    whiteRookLeftMoved: Boolean,
    whiteRookRightMoved: Boolean,
    blackRookLeftMoved: Boolean,
    blackRookRightMoved: Boolean,
    lastPawnDoubleMove: Pair<Int, Int>?
): Boolean {
    // A player can only be in checkmate if their king is currently in check
    val kingPos = findKingPosition(board, color)
    if (kingPos == null || !isKingInCheck(
            board,
            kingPos,
            color,
            whiteKingMoved,
            blackKingMoved,
            whiteRookLeftMoved,
            whiteRookRightMoved,
            blackRookLeftMoved,
            blackRookRightMoved,
            lastPawnDoubleMove
        )
    ) {
        return false
    }

    // Now, check if there are any legal moves for any piece of the current color
    for (r in board.indices) {
        for (c in board[r].indices) {
            val piece = board[r][c]
            if (piece.startsWith(color)) {
                // Check all possible destination squares
                for (toR in board.indices) {
                    for (toC in board[toR].indices) {
                        if (isMoveValid(
                                piece = piece,
                                from = r to c,
                                to = toR to toC,
                                board = board,
                                whiteKingMoved = whiteKingMoved,
                                blackKingMoved = blackKingMoved,
                                whiteRookLeftMoved = whiteRookLeftMoved,
                                whiteRookRightMoved = whiteRookRightMoved,
                                blackRookLeftMoved = blackRookLeftMoved,
                                blackRookRightMoved = blackRookRightMoved,
                                lastPawnDoubleMove = lastPawnDoubleMove
                            )
                        ) {
                            // Found at least one legal move, so it's not checkmate
                            return false
                        }
                    }
                }
            }
        }
    }
    // No legal moves were found
    return true
}

// New function to check for stalemate
fun isStalemate(
    board: List<List<String>>,
    color: String,
    whiteKingMoved: Boolean,
    blackKingMoved: Boolean,
    whiteRookLeftMoved: Boolean,
    whiteRookRightMoved: Boolean,
    blackRookLeftMoved: Boolean,
    blackRookRightMoved: Boolean,
    lastPawnDoubleMove: Pair<Int, Int>?
): Boolean {
    // A player can only be in stalemate if their king is NOT in check
    val kingPos = findKingPosition(board, color)
    if (kingPos == null || isKingInCheck(
            board,
            kingPos,
            color,
            whiteKingMoved,
            blackKingMoved,
            whiteRookLeftMoved,
            whiteRookRightMoved,
            blackRookLeftMoved,
            blackRookRightMoved,
            lastPawnDoubleMove
        )
    ) {
        return false
    }

    // Now, check if there are any legal moves for any piece of the current color
    for (r in board.indices) {
        for (c in board[r].indices) {
            val piece = board[r][c]
            if (piece.startsWith(color)) {
                // Check all possible destination squares
                for (toR in board.indices) {
                    for (toC in board[toR].indices) {
                        if (isMoveValid(
                                piece = piece,
                                from = r to c,
                                to = toR to toC,
                                board = board,
                                whiteKingMoved = whiteKingMoved,
                                blackKingMoved = blackKingMoved,
                                whiteRookLeftMoved = whiteRookLeftMoved,
                                whiteRookRightMoved = whiteRookRightMoved,
                                blackRookLeftMoved = blackRookLeftMoved,
                                blackRookRightMoved = blackRookRightMoved,
                                lastPawnDoubleMove = lastPawnDoubleMove
                            )
                        ) {
                            // Found at least one legal move, so it's not stalemate
                            return false
                        }
                    }
                }
            }
        }
    }
    // No legal moves were found, and the king is not in check
    return true
}

fun getPieceImage(piece: String): Int? {
    return when (piece) {
        // Black Pieces
        in listOf("Black Rook Left", "Black Rook Right") -> R.drawable.rook_black
        in listOf("Black Knight Left", "Black Knight Right") -> R.drawable.knight_black
        in listOf("Black Bishop Left", "Black Bishop Right") -> R.drawable.bishop_black
        "Black Queen" -> R.drawable.queen_black
        "Black King" -> R.drawable.king_black
        in listOf(
            "Black Pawn 1", "Black Pawn 2", "Black Pawn 3", "Black Pawn 4",
            "Black Pawn 5", "Black Pawn 6", "Black Pawn 7", "Black Pawn 8"
        ) -> R.drawable.pawn_black

        // White Pieces
        in listOf("White Rook Left", "White Rook Right") -> R.drawable.rook_white
        in listOf("White Knight Left", "White Knight Right") -> R.drawable.knight_white
        in listOf("White Bishop Left", "White Bishop Right") -> R.drawable.bishop_white
        "White Queen" -> R.drawable.queen_white
        "White King" -> R.drawable.king_white
        in listOf(
            "White Pawn 1", "White Pawn 2", "White Pawn 3", "White Pawn 4",
            "White Pawn 5", "White Pawn 6", "White Pawn 7", "White Pawn 8"
        ) -> R.drawable.pawn_white

        else -> null // Return null for empty squares
    }
}

fun isMoveValid(
    piece: String,
    from: Pair<Int, Int>,
    to: Pair<Int, Int>,
    board: List<List<String>>,
    whiteKingMoved: Boolean,
    blackKingMoved: Boolean,
    whiteRookLeftMoved: Boolean,
    whiteRookRightMoved: Boolean,
    blackRookLeftMoved: Boolean,
    blackRookRightMoved: Boolean,
    lastPawnDoubleMove: Pair<Int, Int>?, // New parameter
    simulateCheck: Boolean = true
): Boolean {
    val rowDiff = to.first - from.first
    val colDiff = to.second - from.second
    val targetPiece = board[to.first][to.second]

    // Can't capture own piece
    if (targetPiece.isNotEmpty() && piece.startsWith("White") == targetPiece.startsWith("White")) {
        return false
    }

    // Determine if it is a capture
    val isCapture = targetPiece.isNotEmpty()

    // Basic piece move rules:
    val validBasicMove = when {
        // White Pawn
        piece.startsWith("White Pawn") -> {
            val isStandardMove =
                (rowDiff == -1 && colDiff == 0 && targetPiece.isEmpty()) ||  // Move forward one
                        (from.first == 6 && rowDiff == -2 && colDiff == 0 && board[from.first - 1][from.second].isEmpty() && targetPiece.isEmpty()) || // Two squares first move
                        (isCapture && rowDiff == -1 && Math.abs(colDiff) == 1)

            val isEnPassant = lastPawnDoubleMove != null &&
                    to == (from.first - 1 to lastPawnDoubleMove.second) &&
                    from.first == 3 && Math.abs(colDiff) == 1 &&
                    board[to.first][to.second].isEmpty()

            isStandardMove || isEnPassant
        }

        // Black Pawn
        piece.startsWith("Black Pawn") -> {
            val isStandardMove = (rowDiff == 1 && colDiff == 0 && targetPiece.isEmpty()) ||
                    (from.first == 1 && rowDiff == 2 && colDiff == 0 && board[from.first + 1][from.second].isEmpty() && targetPiece.isEmpty()) ||
                    (isCapture && rowDiff == 1 && Math.abs(colDiff) == 1)

            val isEnPassant = lastPawnDoubleMove != null &&
                    to == (from.first + 1 to lastPawnDoubleMove.second) &&
                    from.first == 4 && Math.abs(colDiff) == 1 &&
                    board[to.first][to.second].isEmpty()

            isStandardMove || isEnPassant
        }

        // Rook
        piece.startsWith("White Rook") || piece.startsWith("Black Rook") ->
            (rowDiff == 0 || colDiff == 0) && isPathClear(from, to, board)

        // Bishop
        piece.startsWith("White Bishop") || piece.startsWith("Black Bishop") ->
            Math.abs(rowDiff) == Math.abs(colDiff) && isPathClear(from, to, board)

        // Queen
        piece.startsWith("White Queen") || piece.startsWith("Black Queen") ->
            (rowDiff == 0 || colDiff == 0 || Math.abs(rowDiff) == Math.abs(colDiff)) && isPathClear(
                from,
                to,
                board
            )

        // Knight
        piece.startsWith("White Knight") || piece.startsWith("Black Knight") ->
            (Math.abs(rowDiff) == 2 && Math.abs(colDiff) == 1) || (Math.abs(rowDiff) == 1 && Math.abs(
                colDiff
            ) == 2)

        // King
        piece.startsWith("White King") || piece.startsWith("Black King") -> {
            val isStandardMove = Math.abs(rowDiff) <= 1 && Math.abs(colDiff) <= 1
//            if (isStandardMove) return isStandardMove todo (inja taghir dade shode )
            val color = if (piece.startsWith("White")) "White" else "Black"
            if (isStandardMove) {
                if (simulateCheck) {
                    val newBoard = board.mapIndexed { r, row ->
                        row.mapIndexed { c, cell ->
                            when {
                                r == from.first && c == from.second -> ""
                                r == to.first && c == to.second -> piece
                                else -> cell
                            }
                        }
                    }

                    if (isKingInCheck(newBoard, to, color,
                            whiteKingMoved, blackKingMoved,
                            whiteRookLeftMoved, whiteRookRightMoved,
                            blackRookLeftMoved, blackRookRightMoved,
                            lastPawnDoubleMove)) return false
                }
                return true
            }


            // Check for castling move
            val isCastlingMove = from.first == to.first && Math.abs(colDiff) == 2
            if (isCastlingMove) {

                val kingRow = from.first

                if ((color == "White" && whiteKingMoved) || (color == "Black" && blackKingMoved)) {
                    return false
                }

                val isKingside = colDiff > 0
                val rookCol = if (isKingside) 7 else 0
                val rookName = if (isKingside) "${color} Rook Right" else "${color} Rook Left"
                val rookMoved =
                    if (isKingside) (if (color == "White") whiteRookRightMoved else blackRookRightMoved)
                    else (if (color == "White") whiteRookLeftMoved else blackRookLeftMoved)

                if (board[kingRow][rookCol] != rookName || rookMoved) {
                    return false
                }

                val startCol = minOf(from.second, rookCol)
                val endCol = maxOf(from.second, rookCol)
                for (c in (startCol + 1) until endCol) {
                    if (board[kingRow][c].isNotEmpty()) return false
                }

                if (isKingInCheck(
                        board,
                        from,
                        color,
                        whiteKingMoved,
                        blackKingMoved,
                        whiteRookLeftMoved,
                        whiteRookRightMoved,
                        blackRookLeftMoved,
                        blackRookRightMoved,
                        lastPawnDoubleMove
                    )
                ) return false

                val path1 = from.first to from.second + Integer.signum(colDiff)
                val path2 = to
                if (isKingInCheck(
                        board,
                        path1,
                        color,
                        whiteKingMoved,
                        blackKingMoved,
                        whiteRookLeftMoved,
                        whiteRookRightMoved,
                        blackRookLeftMoved,
                        blackRookRightMoved,
                        lastPawnDoubleMove
                    )
                ) return false
                if (isKingInCheck(
                        board,
                        path2,
                        color,
                        whiteKingMoved,
                        blackKingMoved,
                        whiteRookLeftMoved,
                        whiteRookRightMoved,
                        blackRookLeftMoved,
                        blackRookRightMoved,
                        lastPawnDoubleMove
                    )
                ) return false

                return true
            }
            isCastlingMove
        }

        else -> false
    }

    if (!validBasicMove) return false

    val color = if (piece.startsWith("White")) "White" else "Black"

    // Simulate move to check if it puts your own king in check
    if (simulateCheck) {
        val newBoard = board.mapIndexed { r, row ->
            row.mapIndexed { c, cell ->
                when {
                    r == from.first && c == from.second -> ""
                    r == to.first && c == to.second -> piece
                    // Handle captured pawn for en passant
                    piece.startsWith("White Pawn") && to.first == from.first - 1 && Math.abs(to.second - from.second) == 1 && c == to.second && r == from.first -> ""
                    piece.startsWith("Black Pawn") && to.first == from.first + 1 && Math.abs(to.second - from.second) == 1 && c == to.second && r == from.first -> ""
                    else -> cell
                }
            }
        }
        val kingPos = if (piece.startsWith("King")) to else findKingPosition(newBoard, color)

        if (kingPos != null && isKingInCheck(
                newBoard,
                kingPos,
                color,
                whiteKingMoved,
                blackKingMoved,
                whiteRookLeftMoved,
                whiteRookRightMoved,
                blackRookLeftMoved,
                blackRookRightMoved,
                lastPawnDoubleMove
            )
        ) {
            return false
        }
    }

    return true
}

fun isPathClear(from: Pair<Int, Int>, to: Pair<Int, Int>, board: List<List<String>>): Boolean {
    val rowStep = Integer.signum(to.first - from.first)
    val colStep = Integer.signum(to.second - from.second)

    var currentRow = from.first + rowStep
    var currentCol = from.second + colStep

    while (currentRow != to.first || currentCol != to.second) {
        if (board[currentRow][currentCol].isNotEmpty()) return false // Found a piece blocking the way
        currentRow += rowStep
        currentCol += colStep
    }
    return true
}

// Find the king position for a given color on the board
fun findKingPosition(board: List<List<String>>, color: String): Pair<Int, Int>? {
    val kingName = if (color == "White") "White King" else "Black King"
    board.forEachIndexed { r, row ->
        row.forEachIndexed { c, cell ->
            if (cell == kingName) return r to c
        }
    }
    return null
}

fun isKingInCheck(
    board: List<List<String>>,
    kingPos: Pair<Int, Int>,
    color: String,
    whiteKingMoved: Boolean,
    blackKingMoved: Boolean,
    whiteRookLeftMoved: Boolean,
    whiteRookRightMoved: Boolean,
    blackRookLeftMoved: Boolean,
    blackRookRightMoved: Boolean,
    lastPawnDoubleMove: Pair<Int, Int>?
): Boolean {
    val opponentColor = if (color == "White") "Black" else "White"

    for (r in board.indices) {
        for (c in board[r].indices) {
            val piece = board[r][c]
            if (piece.startsWith(opponentColor)) {
                // Here simulateCheck = false to avoid infinite loop
                if (isMoveValid(
                        piece,
                        r to c,
                        kingPos,
                        board,
                        whiteKingMoved = whiteKingMoved,
                        blackKingMoved = blackKingMoved,
                        whiteRookLeftMoved = whiteRookLeftMoved,
                        whiteRookRightMoved = whiteRookRightMoved,
                        blackRookLeftMoved = blackRookLeftMoved,
                        blackRookRightMoved = blackRookRightMoved,
                        lastPawnDoubleMove = lastPawnDoubleMove,
                        simulateCheck = false
                    )
                ) {
                    return true
                }
            }
        }
    }

    return false
}

@Preview(showBackground = true)
@Composable
private fun ScreenPreview() {
    NewGameScreen(
        navController = rememberNavController(),
        themeViewModel = viewModel()
    )
}