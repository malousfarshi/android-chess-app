package com.example.chess_test.data_store

import android.content.Context
import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.serialization.descriptors.StructureKind

// 🔒 DataStore Singleton
object UserPreferences {
    private val Context.dataStore by preferencesDataStore(name = "user_prefs")

    private val USERNAME_KEY = stringPreferencesKey("user_username")
    private val PASSWORD_KEY = stringPreferencesKey("user_password")

    suspend fun saveCredentials(context: Context, username: String, password: String) {
        context.dataStore.edit { prefs ->
            prefs[USERNAME_KEY] = username
            prefs[PASSWORD_KEY] = password
        }
    }

    fun getCredentials(context: Context): Flow<Pair<String, String>> =
        context.dataStore.data.map { prefs ->
            val username = prefs[USERNAME_KEY] ?: ""
            val password = prefs[PASSWORD_KEY] ?: ""
            username to password
        }
}

// 🏠 Main Activity
class MainSignUpScreen : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            Surface(modifier = Modifier.fillMaxSize()) {
                UserForm()
            }
        }
    }
}

@Composable
fun UserForm() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    var username by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var savedUsername by remember { mutableStateOf("") }
    var savedPassword by remember { mutableStateOf("") }

    // Load saved credentials
    LaunchedEffect(Unit) {
        scope.launch {
            UserPreferences.getCredentials(context).collectLatest { (u, p) ->
                savedUsername = u
                savedPassword = p
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("🔐 Enter Credentials", style = MaterialTheme.typography.headlineSmall)

        TextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("Username") },
            modifier = Modifier.fillMaxWidth()
        )

        TextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            modifier = Modifier.fillMaxWidth()
        )

        Button(
            onClick = {
                scope.launch {
                     UserPreferences.saveCredentials(context, username, password)
                    Toast.makeText(context, "✅ Credentials saved!", Toast.LENGTH_SHORT).show()
                }
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("Save")
        }

        Spacer(modifier = Modifier.height(32.dp))
        HorizontalDivider(thickness = 1.dp, color = Color.Gray)

        Text("📦 Stored Credentials", style = MaterialTheme.typography.titleMedium)
        Text("Username: $savedUsername")
        Text("Password: $savedPassword")
    }
}

// 🎨 Preview
@Preview(showBackground = true)
@Composable
fun GreetingPreview() {

    Text("Preview not available for form")

}
