package com.example.chess_test.ui.theme

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.MutableState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chess_test.data_store.UserPreferences
import com.example.chessgame.R
import com.example.chessgame.color.DarkGreen
import com.example.chessgame.color.Moccasin
import com.example.chessgame.color.SaddleBrown
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.launch

fun Context.findActivity3(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity3()
    else -> null
}

@Composable
fun LoginScreenTest(navController: NavController, themeViewModel: ThemeViewModel) {
    val backgroundColor = themeViewModel.backgroundColor
    val font = themeViewModel.font
    val fontSize = themeViewModel.fontSize

    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val coroutineScope = rememberCoroutineScope()
    val shouldShowDialog = remember { mutableStateOf(false) }
    if (shouldShowDialog.value) {
        AlertDialogConfirmExitDialog(shouldShowDialog = shouldShowDialog)
    }

    val inputUsername = remember { mutableStateOf("") }
    val inputPassword = remember { mutableStateOf("") }
    var isPasswordVisible by remember { mutableStateOf(false) }

    val storedUsername = remember { mutableStateOf("") }
    val storedPassword = remember { mutableStateOf("") }

    LaunchedEffect(Unit) {
        scope.launch {
            UserPreferences.getCredentials(context).collectLatest { (username, password) ->
                storedUsername.value = username
                storedPassword.value = password
            }
        }
    }
//
//    LaunchedEffect(key1 = true) {
//        // Stagger the animations to make them appear sequentially
//        delay(200) // Delay before button animation starts
//        showButton = true // Trigger the button animation
//    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor),

        )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
    ) {
        Text(
            text = stringResource(id = R.string.App_title), //todo change from hardcoded string to string resource
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 36.dp),
            fontFamily = font,
            fontSize = (24.sp),
            fontWeight = FontWeight.Bold,
            color = DarkGreen,
        )
        Text(
            text = "Play chess anytime, anywhere",
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 36.dp),
            fontFamily = font,
            fontSize = (20.sp),
            fontWeight = FontWeight.Bold,
            color = DarkGreen,
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Username TextField
        OutlinedTextField(
            value = inputUsername.value,
            onValueChange = { inputUsername.value = it },
            label = { Text("Username") },
            maxLines = 1,
            singleLine = true,
            isError = inputUsername.value.length > 15,
            visualTransformation = VisualTransformation.None,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp)
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Password TextField
        OutlinedTextField(
            value = inputPassword.value,
            onValueChange = { inputPassword.value = it },
            label = { Text("Password") },
            maxLines = 1,
            singleLine = true,
            isError = inputPassword.value.length > 15,
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),

            trailingIcon = {
                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                    Icon(
                        imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                    )
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),


            )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = {
                if (inputUsername.value == storedUsername.value &&
                    inputPassword.value == storedPassword.value

                ) {
                    navController.navigate("Menu Screen")
                    Toast.makeText(context, "✅ Login successful!", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(
                        context,
                        "❌ Failed to connect. Invalid credentials.",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Sign In",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                navController.navigate("Sign up screen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Sign Up",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                navController.navigate("")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Sign in with google",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                navController.navigate("New Game Screen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Offline Mode",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                coroutineScope.launch {
                    delay(500)
                    shouldShowDialog.value = true
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Exit",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Image(
            modifier = Modifier
                .alpha(0.5f)
                .padding(6.dp)
                .background(Moccasin)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )
        Text(
            text = "App version v1.0",
            modifier = Modifier
                .padding(horizontal = 14.dp, vertical = 8.dp),
            fontSize = (8.sp),
            fontWeight = FontWeight.Bold,
            fontFamily = FontFamily.Serif,
            color = SaddleBrown
        )


    }
    BackHandler(enabled = true) {
        shouldShowDialog.value = true
    }
}

@Composable
fun AlertDialogConfirmExitDialog(shouldShowDialog: MutableState<Boolean>) {
    val context = LocalContext.current
    if (shouldShowDialog.value) {
        AlertDialog(
            onDismissRequest = {
                shouldShowDialog.value = false
            },
            title = { Text(text = "Exit App") },
            text = { Text(text = "Are you sure you want to exit the app?") },
            confirmButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                        context.findActivity3()?.finishAffinity()
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                )
                {
                    Text(
                        text = "Confirm",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            },
            dismissButton = {
                Button(
                    onClick = {
                        shouldShowDialog.value = false
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
                    ),
                    modifier = Modifier
                        .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
                    shape = RoundedCornerShape(32.dp),
                ) {
                    Text(
                        text = "Dismiss",
                        modifier = Modifier
                            .padding(horizontal = 12.dp, vertical = 6.dp),
                        fontWeight = FontWeight.Bold,
                        color = SaddleBrown
                    )
                }
            }

        )
    }
}


@Preview(showBackground = true)
@Composable
fun LoginScreenPreview() {
    LoginScreenTest(
        navController = rememberNavController(),
        themeViewModel = viewModel()
    )
}