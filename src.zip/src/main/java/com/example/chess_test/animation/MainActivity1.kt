package com.example.chess_test.animation


import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity1 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppScreen()
                }
            }
        }
    }
}

/**
 * An extension function to find the Activity from a Context.
 * This is necessary because Jetpack Compose Composable functions receive a Context,
 * but to finish the app, we need to access the Activity.
 */
fun Context.findActivity(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity()
    else -> null
}

@Composable
fun AppScreen() {
    // Get the current context in the Composable scope
    val context = LocalContext.current

    // This state will control the visibility animation
    var isContentVisible by remember { mutableStateOf(true) }

    // A coroutine scope is needed to introduce a delay before closing the app,
    // allowing the exit animation to complete.
    val coroutineScope = rememberCoroutineScope()

    // This composable animates its content based on the `isContentVisible` state.
    // It uses a fade-out and slide-out animation.
    AnimatedVisibility(
        visible = isContentVisible,
        enter = fadeIn(),
        exit = fadeOut(animationSpec = tween(durationMillis = 500)) + slideOutVertically(animationSpec = tween(durationMillis = 500)) { fullHeight -> fullHeight }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Welcome to the app!",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(32.dp))
            ExitAppButton(onExitClick = {
                // Trigger the exit animation by changing the state
                isContentVisible = false

                // Start a coroutine to wait for the animation to finish
                // before exiting the app
                coroutineScope.launch {
                    delay(400) // Wait for the 500ms exit animation to complete
                    context.findActivity()?.finishAffinity()
                }
            })
        }
    }
}

@Composable
fun ExitAppButton(onExitClick: () -> Unit) {
    // We use an InteractionSource to detect press gestures
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Animate the scale of the button based on its pressed state
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.1f else 1f,
        label = "buttonScaleAnimation"
    )

    Button(
        onClick = onExitClick,
        modifier = Modifier
            .width(200.dp)
            .scale(scale), // Apply the animated scale modifier
        interactionSource = interactionSource // Pass the interaction source to the button
    ) {
        Text(text = "Exit Application")
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview() {
    MaterialTheme {
        AppScreen()
    }
}