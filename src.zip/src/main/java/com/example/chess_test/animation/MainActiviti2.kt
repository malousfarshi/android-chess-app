package com.example.chess_test.animation


import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.animation.*
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity2 : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                // A surface container using the 'background' color from the theme
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    AppScreen2()
                }
            }
        }
    }
}

/**
 * An extension function to find the Activity from a Context.
 * This is necessary because Jetpack Compose Composable functions receive a Context,
 * but to finish the app, we need to access the Activity.
 */
fun Context.findActivity2(): Activity? = when (this) {
    is Activity -> this
    is ContextWrapper -> baseContext.findActivity2()
    else -> null
}

@Composable
fun AppScreen2() {
    // Get the current context in the Composable scope
    val context = LocalContext.current

    // State to control the "on-boot" animation for the content
    var showContent by remember { mutableStateOf(false) }

    // State to control the exit animation
    var isContentVisible by remember { mutableStateOf(true) }

    // A coroutine scope is needed for the animation delay
    val coroutineScope = rememberCoroutineScope()

    // LaunchedEffect runs a suspend block when the key changes.
    // An empty list `remembered` ensures it runs only once when the composable is first displayed.
    LaunchedEffect(key1 = true) {
        delay(500) // Simulate a short loading time
        showContent = true // Trigger the boot-up animation
    }

    // This composable animates its content based on the `showContent` state.
    // It uses a fade-in and slide-in animation for the boot-up.
    AnimatedVisibility(
        visible = showContent,
        enter = fadeIn(animationSpec = tween(durationMillis = 500)) +
                slideInVertically(initialOffsetY = { it / 2 }, animationSpec = tween(durationMillis = 500)),
        exit = fadeOut(animationSpec = tween(durationMillis = 500)) +
                slideOutVertically(animationSpec = tween(durationMillis = 500)) { fullHeight -> fullHeight }
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Text(
                text = "Welcome to the app!",
                style = MaterialTheme.typography.headlineMedium
            )
            Spacer(modifier = Modifier.height(32.dp))
            ExitAppButton2(onExitClick = {
                // Trigger the exit animation by changing the state
                showContent = false

                // Start a coroutine to wait for the animation to finish
                // before exiting the app
                coroutineScope.launch {
                    delay(500) // Wait for the 500ms exit animation to complete
                    context.findActivity2()?.finishAffinity()
                }
            })
        }
    }
}

@Composable
fun ExitAppButton2(onExitClick: () -> Unit) {
    // We use an InteractionSource to detect press gestures
    val interactionSource = remember { MutableInteractionSource() }
    val isPressed by interactionSource.collectIsPressedAsState()

    // Animate the scale of the button based on its pressed state
    val scale by animateFloatAsState(
        targetValue = if (isPressed) 0.95f else 1f, // Corrected scale value
        label = "buttonScaleAnimation"
    )

    Button(
        onClick = onExitClick,
        modifier = Modifier
            .width(200.dp)
            .scale(scale), // Apply the animated scale modifier
        interactionSource = interactionSource // Pass the interaction source to the button
    ) {
        Text(text = "Exit Application")
    }
}

@Preview(showBackground = true)
@Composable
fun DefaultPreview2() {
    MaterialTheme {
        AppScreen2()
    }
}
