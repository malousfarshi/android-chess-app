package com.example.chessgame

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.chess_test.GameScreenTest
import com.example.chess_test.ui.theme.AboutScreen
import com.example.chess_test.ui.theme.NewGameScreen
import com.example.chess_test.ui.theme.LoginScreenTest
import com.example.chess_test.ui.theme.MenuScreenTest
import com.example.chess_test.ui.theme.SignUpScreenTest
import com.example.chess_test.ui.theme.SplashScreenTest
import com.example.chess_test.ui.theme.ThemeViewModel


class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
//            create navigation controller
            val navController = rememberNavController()
            val themeViewModel: ThemeViewModel = viewModel()
//            navigation graph
            NavHost(navController = navController, startDestination = "splashScreen") {
                composable("splashScreen") {
                    SplashScreenTest(navController,themeViewModel)
                }
                composable("Login screen") {
                    LoginScreenTest(navController, themeViewModel)
                }
                composable("Sign up screen") {
                    SignUpScreenTest(navController,themeViewModel)
                }
                composable("Menu screen") {
                    MenuScreenTest(navController,themeViewModel)
                }
                composable("Game screen") {
                    GameScreenTest(navController,themeViewModel)

                }
                composable("About screen") {
                    AboutScreen(navController,themeViewModel)
                }
                composable("New Game Screen") {
                    NewGameScreen(navController,themeViewModel)
                }

            }
        }
    }
}



//@Preview
//@Composable
//fun SplashScreenPreview() {
//    Chess_testTheme {
//        val navController = rememberNavController()
////        SplashScreenTest(navController)
//        //  MenuScreenTest(navController)
//        GameScreenTest(navCon000
//
//
//    }
//}






