package com.example.chess_test.ui.theme

import android.R.attr.font
import android.R.attr.fontWeight
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chessgame.R
import com.example.chessgame.color.BlanchedAlmond
import com.example.chessgame.color.BurlyWood
import com.example.chessgame.color.LemonChiffon
import com.example.chessgame.color.Moccasin
import com.example.chessgame.color.OldLace
import com.example.chessgame.color.Peru
import com.example.chessgame.color.Pink
import com.example.chessgame.color.RosyBrown
import com.example.chessgame.color.SaddleBrown
import com.example.chessgame.color.SandyBrown
import com.example.chessgame.color.Tan

@Composable
fun AboutScreen(navController: NavController, themeViewModel: ThemeViewModel) {
    val backgroundColor = themeViewModel.backgroundColor
    val font = themeViewModel.font
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor)
            .padding(16.dp)
    )
    {
        Spacer(modifier = Modifier.height(40.dp))
        Box(
            modifier = Modifier
                .align(Alignment.Start)
                .padding(16.dp)
                .background(SandyBrown, shape = RoundedCornerShape(16.dp)),


            ) {
            Text(
                text = "About Of Chess",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (18.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(SandyBrown, shape = RoundedCornerShape(16.dp))
        ) {
            Text(
                text = "History Of Chess",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (12.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(
                    Color(0xFFD2B48C).copy(alpha = 0.4f),
                    shape = RoundedCornerShape(16.dp)
                ),


            ) {
            Text(
                text = "Chess is one of the oldest strategy games in the world, originating in India in the 6th century.\n" +
                        "It spread through Persia to the Arab world and then to Europe.\n" +
                        "The modern form of chess took shape in 15th-century Europe.",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (10.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(SandyBrown, shape = RoundedCornerShape(16.dp)),


            ) {
            Text(
                text = "Timeless Chess Masters",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (12.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown

            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(
                    Color(0xFFD2B48C).copy(alpha = 0.4f),
                    shape = RoundedCornerShape(16.dp)
                ),


            ) {
            Text(
                text = "Capablanca was a Cuban chess legend known for his natural talent and simple, elegant style in the early 20th century.\n" +
                        "Kasparov dominated the chess world with his aggressive and strategic play, becoming a symbol of modern chess mastery.\n" +
                        "\n" +
                        "Carlsen, a Norwegian prodigy, blends tactics and strategy with calm precision, representing the peak of contemporary chess.\n" +
                        "\n",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (10.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(SandyBrown, shape = RoundedCornerShape(16.dp)),


            ) {
            Text(
                text = "About Me",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (12.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Box(
            modifier = Modifier
                .padding(16.dp)
                .background(
                    Color(0xFFD2B48C).copy(alpha = 0.4f),
                    shape = RoundedCornerShape(16.dp)
                ),

            ) {
            Text(
                text = "A lifelong chess player, I built this app to showcase my passion for programming and love for the game.",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontSize = (10.sp),
                fontWeight = FontWeight.Bold,
                fontFamily = font,
                color = SaddleBrown
            )
        }
        Button(
            onClick = {
                navController.popBackStack()
//                navController.navigate("Menu Screen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFD2B48C).copy(alpha = 0.4f),
            ),
            modifier = Modifier
                .align(Alignment.End)
                .padding(16.dp)
                .width(60.dp)
                .height(30.dp),
            shape = RoundedCornerShape(32.dp),
            contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Back",
                modifier = Modifier,
                fontFamily = font,
                fontSize = (8.sp),
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Image(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.5f)
                .padding(6.dp)
                .background(Moccasin)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )
    }
}


@Composable
@Preview(showBackground = true)
fun AboutScreenPreview() {
    AboutScreen(
        navController = rememberNavController(),
        themeViewModel = viewModel()
    )
}