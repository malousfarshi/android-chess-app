package com.example.chess_test.ui.theme

import android.R.attr.font
import android.app.Activity
import android.content.Context
import android.preference.ListPreference
import android.widget.Toast
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextFieldDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.datastore.dataStoreFile
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavController
import androidx.navigation.compose.rememberNavController
import com.example.chessgame.R
import com.example.chessgame.color.DarkGreen
import com.example.chessgame.color.Moccasin
import com.example.chessgame.color.SaddleBrown
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.collectLatest
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.util.Locale

object UserPreferences {
    private val Context.dataStore by preferencesDataStore(name = "user_prefs_chess")
    private val USERNAME_KEY = stringPreferencesKey("user_username")
    private val FULLNAME_KEY = stringPreferencesKey("user_fullname")
    private val PASSWORD_KEY = stringPreferencesKey("user_password")
    private val EMAIL_KEY = stringPreferencesKey("user_email")
    private val COUNTRY_KEY = stringPreferencesKey("user_country")

    suspend fun saveCredentials(
        context: Context,
        username: String,
        fullname: String,
        password: String,
        email: String,
        country: String
    ) {
        context.dataStore.edit { prefs ->
            prefs[USERNAME_KEY] = username
            prefs[FULLNAME_KEY] = fullname
            prefs[PASSWORD_KEY] = password
            prefs[EMAIL_KEY] = email
            prefs[COUNTRY_KEY] = country
        }
    }

    fun getCredentials(context: Context): Flow<List<String>> =
        context.dataStore.data.map { prefs ->
            val username = prefs[USERNAME_KEY] ?: ""
            val fullname = prefs[FULLNAME_KEY] ?: ""
            val password = prefs[PASSWORD_KEY] ?: ""
            val email = prefs[EMAIL_KEY] ?: ""
            val country = prefs[COUNTRY_KEY] ?: ""
            listOf(username, fullname, password, email, country)
        }
}

@Composable
fun SignUpScreenTest(navController: NavController, themeViewModel: ThemeViewModel) {
    val context = LocalContext.current
    var username by remember { mutableStateOf("") }
    var fullname by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var country by remember { mutableStateOf("") }
    val scope = rememberCoroutineScope()

    val savedUsername = remember { mutableStateOf("") }
    val savedFullname = remember { mutableStateOf("") }
    val savedPassword = remember { mutableStateOf("") }
    val savedEmail = remember { mutableStateOf("") }
    val savedCountry = remember { mutableStateOf("") }

    var isPasswordVisible by remember { mutableStateOf(false) }

    val backgroundColor = themeViewModel.backgroundColor
    val font = themeViewModel.font
    val fontSize = themeViewModel.fontSize

    LaunchedEffect(Unit) {
        scope.launch {
            UserPreferences.getCredentials(context).collectLatest { (u, f, p, e, c) ->
                savedUsername.value = u
                savedFullname.value = f
                savedPassword.value = p
                savedEmail.value = e
                savedCountry.value = c

            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(backgroundColor),
    )
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),

        ) {
        Text(
            text = "Sign in",
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 36.dp),
            fontFamily = font,
            fontSize = fontSize,
            fontWeight = FontWeight.Bold,
            color = DarkGreen,
            style = MaterialTheme.typography.titleSmall
        )
        Spacer(modifier = Modifier.height(40.dp))
        // Username Field
        OutlinedTextField(
            value = username,
            onValueChange = { username = it },
            label = { Text("User Name") },
            maxLines = 1,
            singleLine = true,
            isError = username.length > 15,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        // fullname Field
        OutlinedTextField(
            value = fullname,
            onValueChange = { fullname = it },
            label = { Text("Full Name") },
            maxLines = 1,
            singleLine = true,
            isError = username.length > 15,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )

        Spacer(modifier = Modifier.height(16.dp))
        // password Field
        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            maxLines = 1,
            singleLine = true,
            isError = password.length > 15,
            visualTransformation = if (isPasswordVisible) VisualTransformation.None else PasswordVisualTransformation(),

            trailingIcon = {
                IconButton(onClick = { isPasswordVisible = !isPasswordVisible }) {
                    Icon(
                        imageVector = if (isPasswordVisible) Icons.Filled.Visibility else Icons.Filled.VisibilityOff,
                        contentDescription = if (isPasswordVisible) "Hide password" else "Show password"
                    )
                }
            },
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Username Field
        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("E-Mail") },
            maxLines = 1,
            singleLine = true,
            isError = username.length > 15,
            keyboardOptions = KeyboardOptions(
                keyboardType = KeyboardType.Email,
                imeAction = ImeAction.Done
            ),
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        // Username Field
        OutlinedTextField(
            value = country,
            onValueChange = { country = it },
            label = { Text("Country") },
            maxLines = 1,
            singleLine = true,
            isError = username.length > 15,
            colors = TextFieldDefaults.colors(
                focusedContainerColor = Moccasin,
                unfocusedContainerColor = Moccasin,
                disabledContainerColor = Moccasin,
                errorContainerColor = Moccasin,
                focusedIndicatorColor = Color.Blue,
                unfocusedIndicatorColor = Color.Gray,
                disabledIndicatorColor = Color.Gray,
                errorIndicatorColor = Color.Red,
                focusedLabelColor = MaterialTheme.colorScheme.primary,
                unfocusedLabelColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLabelColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLabelColor = MaterialTheme.colorScheme.error,
                focusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPlaceholderColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPlaceholderColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPlaceholderColor = MaterialTheme.colorScheme.error,
                focusedTextColor = MaterialTheme.colorScheme.onSurface,
                unfocusedTextColor = MaterialTheme.colorScheme.onSurface,
                disabledTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTextColor = MaterialTheme.colorScheme.error,
                focusedLeadingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedLeadingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledLeadingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorLeadingIconColor = MaterialTheme.colorScheme.error,
                focusedTrailingIconColor = MaterialTheme.colorScheme.primary,
                unfocusedTrailingIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledTrailingIconColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorTrailingIconColor = MaterialTheme.colorScheme.error,
                focusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedPrefixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledPrefixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorPrefixColor = MaterialTheme.colorScheme.error,
                focusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSuffixColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSuffixColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSuffixColor = MaterialTheme.colorScheme.error,
                focusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                unfocusedSupportingTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                disabledSupportingTextColor = MaterialTheme.colorScheme.onSurface.copy(0.38f),
                errorSupportingTextColor = MaterialTheme.colorScheme.error,
            ),
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(bottom = 8.dp),
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                scope.launch {
                    UserPreferences.saveCredentials(
                        context,
                        username,
                        fullname,
                        password,
                        email,
                        country
                    )
                    Toast.makeText(context, "✅ Credentials saved!", Toast.LENGTH_SHORT).show()
                    navController.navigate("Login screen")
                }
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {

            Text(
                text = "Submit",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = {
                navController.popBackStack()
                navController.navigate("Login Screen")
            },
            colors = ButtonDefaults.buttonColors(
                containerColor = Color(0xFFDEB887).copy(alpha = 0.4f)
            ),
            modifier = Modifier
                .border(0.dp, color = Color.DarkGray, RoundedCornerShape(32.dp)),
            shape = RoundedCornerShape(32.dp),
            elevation = ButtonDefaults.buttonElevation(0.dp)
        ) {
            Text(
                text = "Cancel",
                modifier = Modifier
                    .padding(horizontal = 14.dp, vertical = 8.dp),
                fontFamily = font,
                fontSize = fontSize,
                fontWeight = FontWeight.Bold,
                color = SaddleBrown
            )
        }
        Spacer(modifier = Modifier.height(16.dp))

      

        Image(
            modifier = Modifier
                .fillMaxSize()
                .alpha(0.5f)
                .padding(6.dp)
                .background(Moccasin)
                .clip(shape = RoundedCornerShape(2.dp)),
            painter = painterResource(id = R.drawable.chesssplash),
            contentDescription = null,
            contentScale = ContentScale.Fit
        )
    }
}


@Preview(showBackground = true)
@Composable
fun SignInScreenPreview() {
    SignUpScreenTest(
        navController = rememberNavController(),
        themeViewModel = viewModel()
    )
}